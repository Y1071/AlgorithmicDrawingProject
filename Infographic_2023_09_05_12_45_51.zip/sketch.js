let infographic;
let end;
let Red;
let DeadBeats;
let Q;
let RIP;

function preload(){
  infographic = loadImage("infographic.png");
  end = loadSound("end of a life.mp3");
  Red = loadSound("Red.mp3");
  DeadBeats = loadSound("DEAD BEATS.mp3");
  Q = loadSound("Q.mp3");
  RIP = loadSound("RIP.mp3");
}

function setup() {
  createCanvas(800, 2000);
}

function draw() {
  background(220);
  image(infographic, 0, 0);
}

function mousePressed(){
  console.log(mouseX,mouseY);
  
  if(mouseX >= 481 && mouseX <= 518 && mouseY >= 584 && mouseY <= 620){
    end.play()
  }
  
  if(mouseX >= 403 && mouseX <= 439 && mouseY >= 927 && mouseY <= 962){
    Red.play()
  }
  
  if(mouseX >= 111 && mouseX <= 148 && mouseY >= 1246 && mouseY <= 1282){
    DeadBeats.play()
  }
  
  if(mouseX >= 702 && mouseX <= 737 && mouseY >= 1555 && mouseY <= 1589){
    Q.play()
  }
  
  if(mouseX >= 127 && mouseX <= 163 && mouseY >= 1886 && mouseY <= 1920){
    RIP.play()
  }
} 

function mouseClicked(){
  //console.log(mouseX,mouseY);
  
  if(mouseX >= 481 && mouseX <= 518 && mouseY >= 584 && mouseY <= 620){
    end.stop()
  }
  
  if(mouseX >= 403 && mouseX <= 439 && mouseY >= 927 && mouseY <= 962){
    Red.stop()
  }
  
  if(mouseX >= 111 && mouseX <= 148 && mouseY >= 1246 && mouseY <= 1282){
    DeadBeats.stop()
  }
  
  if(mouseX >= 702 && mouseX <= 737 && mouseY >= 1555 && mouseY <= 1589){
    Q.stop()
  }
  
  if(mouseX >= 127 && mouseX <= 163 && mouseY >= 1886 && mouseY <= 1920){
    RIP.stop()
  }
} 



